# Intelligent Courier Planning System

A runnable Python prototype that integrates sorting, dynamic programming, shortest-path graph processing, route approximation, and runtime benchmarking.

## Project structure

```
courier_planner_project/
├── courier_planner.py        # integrated application + algorithms
├── data/
│   ├── parcels.csv          # parcel list
│   └── roads.csv            # undirected weighted road graph
├── outputs/                 # generated delivery plan, benchmark data, charts
├── requirements.txt
└── README.md
```

## Requirements

- Python 3.9 or newer
- Matplotlib for chart generation (core algorithm run does not need other packages)

Install the optional chart library:

```bash
python -m pip install -r requirements.txt
```

## Run

Open a terminal in this folder:

```bash
python courier_planner.py
```

Use a different vehicle capacity:

```bash
python courier_planner.py --capacity 25
```

Use different CSV inputs:

```bash
python courier_planner.py --parcels data/parcels.csv --roads data/roads.csv --capacity 30
```

Benchmark-only mode:

```bash
python courier_planner.py --benchmark-only
```

Generated outputs appear in `outputs/`:
- `delivery_plan.txt`: sorted list, selected parcels, route, distance and component timings
- `benchmark.csv`: synthetic benchmark measurements
- `runtime_chart.png`: runtime comparison for the sample case
- `route_distance_chart.png`: sample route distance plot
- `*_benchmark.png`: scaling charts for each component

## Algorithm design

### 1. Merge Sort — parcel prioritization
Stable merge sort ranks parcels by priority (descending), deadline (ascending), value (descending), then parcel ID. Merge Sort is O(n log n) in the worst case.

### 2. 0/1 Knapsack DP — vehicle packing
The capacity is in kilograms. Each parcel is either included or excluded. The DP objective combines parcel priority, urgency (earlier deadline receives a bonus), and value. The recurrence is:

`DP[i][c] = max(DP[i-1][c], DP[i-1][c-weight[i]] + benefit[i])`

Time complexity: O(nC), where C is the integer capacity. The current version uses integer kilogram weights/capacity for clarity.

### 3. Dijkstra — shortest paths
The roads file is interpreted as an undirected weighted graph. Dijkstra is run from every graph node to create a shortest-path distance matrix and path lookup. With adjacency lists and a binary heap, each run is approximately O((V+E) log V).

### 4. Nearest Neighbor TSP approximation — route ordering
Selected parcel destinations are deduplicated. Starting from the depot, the nearest unvisited destination is selected using shortest-path distances. The route returns to the depot. This is a heuristic (not guaranteed globally optimal); its route-ordering step is O(k²) for k distinct delivery locations.

## Data formats

`parcels.csv` columns:
- `parcel_id`: unique parcel identifier
- `location`: destination graph node
- `weight`: parcel weight in kg (integer)
- `priority`: 1–5, larger means more important
- `deadline`: hours from trip start; smaller is more urgent
- `value`: relative value/benefit score

`roads.csv` columns:
- `from`, `to`: node IDs
- `distance_km`: positive edge distance

The graph must include the depot node `DEPOT` and each parcel destination, and must be connected for the sample routing use case.


## Sample run (reference output)

- Sorted parcels: P107, P104, P101, P106, P102, P110, P108, P103, P109, P105
- Selected parcels: P107, P104, P101, P106, P102, P110
- Packed weight: 29 / 30 kg
- Visit route: DEPOT → N1 → N2 → N4 → N6 → N8 → DEPOT
- Expanded shortest-road path: DEPOT → N1 → N2 → N3 → N4 → N7 → N6 → N8 → N7 → N4 → DEPOT
- Estimated distance: 36 km

Runtime figures vary by computer and system load. Use the generated charts and CSV as your own run's measured results; avoid claiming these times are universal.

## Limitations and future improvements

- Nearest Neighbor is a TSP approximation and can produce suboptimal routes. Compare with 2-opt local search or an exact solver for small stop counts.
- Deadlines influence sorting and DP score, but route ETA/time windows are not yet checked as hard constraints.
- Parcel weights are integer kg; scale to grams or use a discretized capacity for fractional weights.
- The graph uses static distance only; add travel time, traffic, one-way edges and time-dependent costs for realism.
- Packing optimizes a combined score, not a formal multi-objective deadline feasibility model.
- Benchmark values are machine-dependent and use synthetic inputs.

## Phase rubric mapping

| Phase | Implemented evidence |
|---|---|
| 1 — Design and planning | This README, data model, graph CSV, algorithm pipeline |
| 2 — Sorting and packing | Merge Sort output, 0/1 DP selection, capacity result in `delivery_plan.txt` |
| 3 — Graph and route | Dijkstra distance/path matrix and Nearest Neighbor route/distance |
| 4 — Performance | `benchmark.csv`, runtime and scaling plots |
| 5 — Report/demo | This documentation, generated output files and screenshot-style evidence in `outputs/` |

