#!/usr/bin/env python3
"""Intelligent Courier Planning System: sorting, DP packing, graph routing, benchmarking."""
from __future__ import annotations
import csv, heapq, math, random, time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
OUT = ROOT / 'outputs'

@dataclass
class Parcel:
    parcel_id: str
    location: str
    weight: int
    priority: int
    deadline: int  # hour from start; smaller = more urgent
    value: int


def load_parcels(path: Path) -> List[Parcel]:
    with path.open(newline='', encoding='utf-8') as f:
        return [Parcel(r['parcel_id'], r['location'], int(r['weight']), int(r['priority']), int(r['deadline']), int(r['value'])) for r in csv.DictReader(f)]


def load_graph(path: Path) -> Dict[str, Dict[str, float]]:
    graph: Dict[str, Dict[str, float]] = {}
    with path.open(newline='', encoding='utf-8') as f:
        for r in csv.DictReader(f):
            a, b, d = r['from'], r['to'], float(r['distance_km'])
            graph.setdefault(a, {})[b] = d
            graph.setdefault(b, {})[a] = d
    return graph


def merge_sort_parcels(items: List[Parcel]) -> List[Parcel]:
    """Stable merge sort: priority descending, deadline ascending, value descending."""
    if len(items) <= 1:
        return items[:]
    mid = len(items) // 2
    left, right = merge_sort_parcels(items[:mid]), merge_sort_parcels(items[mid:])
    out, i, j = [], 0, 0
    def key(p): return (-p.priority, p.deadline, -p.value, p.parcel_id)
    while i < len(left) and j < len(right):
        if key(left[i]) <= key(right[j]): out.append(left[i]); i += 1
        else: out.append(right[j]); j += 1
    out.extend(left[i:]); out.extend(right[j:])
    return out


def knapsack_dp(parcels: List[Parcel], capacity: int) -> Tuple[List[Parcel], int]:
    """0/1 knapsack. Benefit blends priority, urgency and declared parcel value."""
    n = len(parcels)
    benefits = [p.priority * 100 + max(0, 48 - p.deadline) * 3 + p.value for p in parcels]
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    for i, p in enumerate(parcels, 1):
        for c in range(capacity + 1):
            dp[i][c] = dp[i-1][c]
            if p.weight <= c:
                dp[i][c] = max(dp[i][c], dp[i-1][c-p.weight] + benefits[i-1])
    chosen, c = [], capacity
    for i in range(n, 0, -1):
        if dp[i][c] != dp[i-1][c]:
            chosen.append(parcels[i-1]); c -= parcels[i-1].weight
    chosen.reverse()
    return chosen, dp[n][capacity]


def dijkstra(graph: Dict[str, Dict[str, float]], start: str) -> Tuple[Dict[str, float], Dict[str, str]]:
    dist = {node: math.inf for node in graph}; prev = {}
    if start not in graph: return dist, prev
    dist[start] = 0.0; heap = [(0.0, start)]
    while heap:
        d, u = heapq.heappop(heap)
        if d != dist[u]: continue
        for v, w in graph[u].items():
            nd = d + w
            if nd < dist[v]: dist[v], prev[v] = nd, u; heapq.heappush(heap, (nd, v))
    return dist, prev


def reconstruct_path(prev: Dict[str, str], start: str, end: str) -> List[str]:
    if start == end: return [start]
    if end not in prev: return []
    path, cur = [end], end
    while cur != start:
        cur = prev[cur]
        path.append(cur)
    return list(reversed(path))


def all_pairs_shortest(graph):
    distances, paths = {}, {}
    for start in graph:
        dist, prev = dijkstra(graph, start)
        for end in graph:
            distances[(start, end)] = dist[end]
            paths[(start, end)] = reconstruct_path(prev, start, end) if math.isfinite(dist[end]) else []
    return distances, paths


def nearest_neighbor_route(stops: List[str], depot: str, distances) -> Tuple[List[str], float]:
    """TSP approximation on shortest-path distance matrix, with return to depot."""
    unvisited = set(stops); route = [depot]; current = depot; total = 0.0
    while unvisited:
        nxt = min(unvisited, key=lambda x: (distances[(current, x)], x))
        d = distances[(current, nxt)]
        if not math.isfinite(d): raise ValueError(f'No graph path from {current} to {nxt}')
        total += d; route.append(nxt); unvisited.remove(nxt); current = nxt
    total += distances[(current, depot)]; route.append(depot)
    return route, total


def expand_route(route, paths):
    expanded = []
    for a, b in zip(route, route[1:]):
        segment = paths[(a,b)]
        if not segment: continue
        expanded.extend(segment if not expanded else segment[1:])
    return expanded


def run_plan(parcels, graph, capacity, depot='DEPOT'):
    t0=time.perf_counter(); sorted_parcels=merge_sort_parcels(parcels); sort_ms=(time.perf_counter()-t0)*1000
    t0=time.perf_counter(); selected, score=knapsack_dp(sorted_parcels,capacity); dp_ms=(time.perf_counter()-t0)*1000
    t0=time.perf_counter(); distances, paths=all_pairs_shortest(graph); dijkstra_ms=(time.perf_counter()-t0)*1000
    stops=sorted({p.location for p in selected})
    t0=time.perf_counter(); route, km=nearest_neighbor_route(stops,depot,distances) if stops else ([depot,depot],0); route_ms=(time.perf_counter()-t0)*1000
    return {'sorted':sorted_parcels,'selected':selected,'score':score,'distances':distances,'paths':paths,'stops':stops,'route':route,'expanded':expand_route(route,paths) if stops else [depot],'km':km,'times':{'merge_sort_ms':sort_ms,'knapsack_dp_ms':dp_ms,'all_dijkstra_ms':dijkstra_ms,'nearest_neighbor_ms':route_ms}}


def benchmark():
    """Benchmark component timings using reproducible synthetic inputs."""
    random.seed(7); rows=[]
    graph_sizes=[12,30,60,100]
    parcel_sizes=[20,50,100,200]
    for n in parcel_sizes:
        ps=[Parcel(f'P{i}',f'N{i%8+1}',random.randint(1,10),random.randint(1,5),random.randint(2,48),random.randint(10,100)) for i in range(n)]
        t=time.perf_counter(); merge_sort_parcels(ps); sort=(time.perf_counter()-t)*1000
        t=time.perf_counter(); knapsack_dp(ps,50); dp=(time.perf_counter()-t)*1000
        rows.append({'dataset_size':n,'merge_sort_ms':sort,'knapsack_dp_ms':dp})
    # Graph tests: connected random weighted graph; Dijkstra from all nodes and NN on all nodes
    for n in graph_sizes:
        g={f'N{i}':{} for i in range(n)}
        for i in range(n):
            j=(i+1)%n; w=random.randint(1,15); g[f'N{i}'][f'N{j}']=w; g[f'N{j}'][f'N{i}']=w
        for i in range(n):
            for j in range(i+2,n):
                if random.random()<0.12:
                    w=random.randint(1,20); g[f'N{i}'][f'N{j}']=w; g[f'N{j}'][f'N{i}']=w
        t=time.perf_counter(); dist,_=all_pairs_shortest(g); dijkstra=(time.perf_counter()-t)*1000
        t=time.perf_counter(); nearest_neighbor_route([f'N{i}' for i in range(1,n)],'N0',dist); nn=(time.perf_counter()-t)*1000
        rows.append({'dataset_size':n,'all_dijkstra_ms':dijkstra,'nearest_neighbor_ms':nn})
    return rows


def write_outputs(plan, benchmark_rows):
    OUT.mkdir(exist_ok=True)
    with (OUT/'delivery_plan.txt').open('w',encoding='utf-8') as f:
        f.write('INTELLIGENT COURIER PLANNING SYSTEM\n'+'='*38+'\n')
        f.write('SORTED PARCELS (priority desc, deadline asc, value desc)\n')
        for p in plan['sorted']: f.write(f'{p.parcel_id}: location={p.location}, weight={p.weight}kg, priority={p.priority}, deadline={p.deadline}h, value={p.value}\n')
        f.write('\nPACKING SELECTION (0/1 Knapsack DP)\n')
        for p in plan['selected']: f.write(f'{p.parcel_id} -> {p.location} ({p.weight}kg)\n')
        f.write(f'Total weight: {sum(p.weight for p in plan["selected"])} / capacity\nDP score: {plan["score"]}\n')
        f.write('\nROUTE (Nearest Neighbor on Dijkstra shortest-path distances)\n')
        f.write('Visit sequence: '+' -> '.join(plan['route'])+'\n')
        f.write('Expanded road path: '+' -> '.join(plan['expanded'])+'\n')
        f.write(f'Estimated route distance: {plan["km"]:.2f} km\n\nRUNTIME (milliseconds)\n')
        for k,v in plan['times'].items(): f.write(f'{k}: {v:.4f}\n')
    with (OUT/'benchmark.csv').open('w',newline='',encoding='utf-8') as f:
        fields=sorted({k for r in benchmark_rows for k in r}); w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(benchmark_rows)
    try:
        import matplotlib.pyplot as plt
        # runtime chart
        labels=['Merge Sort','Knapsack DP','All Dijkstra','Nearest Neighbor']
        vals=[plan['times'][k] for k in ['merge_sort_ms','knapsack_dp_ms','all_dijkstra_ms','nearest_neighbor_ms']]
        plt.figure(figsize=(8,4.5)); plt.bar(labels,vals); plt.ylabel('Runtime (ms)'); plt.title('Runtime of Core Algorithms (sample dataset)'); plt.xticks(rotation=15,ha='right'); plt.tight_layout(); plt.savefig(OUT/'runtime_chart.png',dpi=160); plt.close()
        # route chart
        plt.figure(figsize=(8,4.5)); plt.bar(['Nearest Neighbor route'],[plan['km']]); plt.ylabel('Distance (km)'); plt.title('Estimated Delivery Route Distance'); plt.tight_layout(); plt.savefig(OUT/'route_distance_chart.png',dpi=160); plt.close()
        # benchmark chart (algorithm timings in their relevant dataset sizes)
        for key,title in [('merge_sort_ms','Merge Sort scaling'),('knapsack_dp_ms','Knapsack DP scaling'),('all_dijkstra_ms','All-pairs Dijkstra scaling'),('nearest_neighbor_ms','Nearest Neighbor scaling')]:
            valid=[r for r in benchmark_rows if key in r]
            if valid:
                plt.figure(figsize=(7,4)); plt.plot([r['dataset_size'] for r in valid],[r[key] for r in valid],marker='o'); plt.xlabel('Input size'); plt.ylabel('Runtime (ms)'); plt.title(title); plt.tight_layout(); plt.savefig(OUT/f'{key}_benchmark.png',dpi=160); plt.close()
    except ImportError:
        print('matplotlib unavailable: charts skipped. Install with pip install matplotlib')


def main():
    import argparse
    parser=argparse.ArgumentParser(description='Intelligent Courier Planner prototype')
    parser.add_argument('--capacity',type=int,default=30,help='vehicle capacity in kg')
    parser.add_argument('--depot',default='DEPOT')
    parser.add_argument('--parcels',type=Path,default=DATA/'parcels.csv')
    parser.add_argument('--roads',type=Path,default=DATA/'roads.csv')
    parser.add_argument('--benchmark-only',action='store_true')
    args=parser.parse_args()
    bench=benchmark()
    if args.benchmark_only:
        write_outputs({'sorted':[],'selected':[],'score':0,'route':[],'expanded':[],'km':0,'times':{'merge_sort_ms':0,'knapsack_dp_ms':0,'all_dijkstra_ms':0,'nearest_neighbor_ms':0}},bench)
        print(f'Benchmark saved in {OUT}'); return
    parcels=load_parcels(args.parcels); graph=load_graph(args.roads)
    plan=run_plan(parcels,graph,args.capacity,args.depot)
    write_outputs(plan,bench)
    print('\n--- COURIER PLAN ---')
    print('Sorted parcel IDs:',', '.join(p.parcel_id for p in plan['sorted']))
    print('Selected parcels:',', '.join(p.parcel_id for p in plan['selected']))
    print('Packed weight:',sum(p.weight for p in plan['selected']),'/',args.capacity,'kg')
    print('Delivery route:', ' -> '.join(plan['route']))
    print('Road path:', ' -> '.join(plan['expanded']))
    print(f'Route distance: {plan["km"]:.2f} km')
    print('\nRuntime (ms):')
    for k,v in plan['times'].items(): print(f'  {k}: {v:.4f}')
    print(f'\nDetailed outputs: {OUT}')

if __name__=='__main__': main()
